from distutils.core import setup

setup(
  name = 'Owens-Cool_package'
  
)